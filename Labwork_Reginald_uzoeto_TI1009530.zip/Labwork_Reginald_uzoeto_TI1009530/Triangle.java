/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Chinaza
 */

    
import java.util.Scanner;

public class Triangle {
    double AB; // length of hypotenuse
  
    public double distanceAC(double AC) 
    {
        return AC;
    }
    public double distanceBC(double BC) 
    {
        return BC;
    }
    
    public double DistanceAB(double AC,double BC) 
    {
       
        return AB=Math.sqrt(Math.pow(AC,2)-Math.pow(BC,2)); 
        
    }
    
    public double cal_Time()
    {
        double Avg_SpeedPer_meter = 1.4; // Normal walking speed per meter
        double time_taken;
        return Math.round(time_taken=AB / Avg_SpeedPer_meter); 
       
        
    }
    
    public static void main(String[] args) {
        double AC=97,BC=72;
        Triangle myobj = new Triangle(); // 
        myobj.DistanceAB(AC, BC); // 
        System.out.println("Distance from A to point B: " + myobj.AB + "m");
        System.out.println("Time taken point A to point B: " + myobj.cal_Time() + "Seconds");
   
}
}

    
