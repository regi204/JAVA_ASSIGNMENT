/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Chinaza
 */
import java.util.Scanner;
public class InterestCalculator {
    double loan,rate,time;
    
    public void simple_interset()
    {
        
        double simpleInterest = ((loan * rate * time) / 100);
        System.out.println("Simple interest : " +simpleInterest);
    }
    
    public void compound_interest()
    {
      double compoundInterest = loan * Math.pow((1 + rate/100), time) - loan;
      System.out.println("Compound interest :" +compoundInterest);
    }
  
    public static void main(String[] args) {
        Scanner myscan = new Scanner(System.in);
        InterestCalculator myobj=new InterestCalculator();
        System.out.println("Enter Loan: ");
        myobj.loan = myscan.nextDouble();
        System.out.println("Enter Rate of Interest: ");
        myobj.rate = myscan.nextDouble();
        System.out.println("Enter Time (in years): ");
        myobj.time = myscan.nextDouble();
        myobj.simple_interset();
        myobj.compound_interest();
    }
}

