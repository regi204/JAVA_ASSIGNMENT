/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Chinaza
 */
import java.util.Scanner;
public class YtmCalculator {
    
        public double c ; // Annual coupon payment
        double f ; // Face value of the bond
        double p ; // Market price of the bond
        double n ; // Number of years until maturity
    
public void calculateYtm() 
    {
        double Ytm=Math.round(((c + (f - p) / n) / ((f + p) / 2))*100);
        System.out.println("Yield to Maturity :" + Ytm + "%");
       
    }

    public static void main(String[] args) {
        YtmCalculator myobj=new YtmCalculator();
        Scanner myscan=new Scanner(System.in);
        System.out.println("Enter coupon/interest payment : ");
        myobj.c=myscan.nextFloat();
        System.out.println("Enter face value : ");
        myobj.f=myscan.nextFloat();
        System.out.println("Enter price : ");
        myobj.p=myscan.nextFloat();
        System.out.println("Enter year to maturity : ");
        myobj.n=myscan.nextFloat();
        myobj.calculateYtm();
       
    }
}


