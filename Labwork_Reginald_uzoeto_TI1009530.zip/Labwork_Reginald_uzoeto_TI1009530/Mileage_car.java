/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**double mpg;     // Miles per gallon
 *
 * @author Chinaza
 */
import java.util.Scanner;
class Mileage
{
    
    float mileage; // Miles driven
    float cost_gas;
    float current_odometer,previous_odometer;
    float gas_added, price_litre;
    
    public void Mileage_covered()
       {   
        mileage=current_odometer-previous_odometer;
        System.out.println("Mileage covered:" +mileage + "km");
        System.out.println("The current mileage : " +current_odometer +"km");
       }
}

public class Mileage_car extends Mileage
{
    public void costGas()
       {
        cost_gas=gas_added*price_litre;
        System.out.println("The cost of gas : $" + cost_gas);
       }
    public void costPer_km()
       {
         float costPer_km=cost_gas/mileage;
         System.out.println("Cost per KM travelled : $" +costPer_km);
       }


public static void main(String[] args)
{
   Scanner myscan=new Scanner(System.in);
   Mileage_car myobj=new Mileage_car();
   System.out.println("The the current odometer: ");
   myobj.current_odometer=myscan.nextFloat();
   System.out.println("The the previous odometer: ");
   myobj.previous_odometer=myscan.nextFloat();
   System.out.println("Enter the quantity of gas in litre : ");
   myobj.gas_added=myscan.nextFloat();
   System.out.println("Enter price of gas by litre : ");
   myobj.price_litre=myscan.nextFloat();
   myobj.Mileage_covered();
   myobj.costGas();
   myobj.costPer_km();
   
}
}










    

