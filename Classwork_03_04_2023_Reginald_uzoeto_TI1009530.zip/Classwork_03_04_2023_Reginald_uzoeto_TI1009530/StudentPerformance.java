
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Chinaza
 */
public class StudentPerformance {
    
      static int n;
      String name;
      int std_id;
      float total=0,percentage;
      
     public void student_details()
     {
        
        System.out.println("Student name : " +name);
        System.out.println("Student ID: " +std_id);
     }
        
    public void percentage()
    {
        percentage=total/n;
        System.out.println("Percentage secured: " +percentage);
    }
          
       
        
}
