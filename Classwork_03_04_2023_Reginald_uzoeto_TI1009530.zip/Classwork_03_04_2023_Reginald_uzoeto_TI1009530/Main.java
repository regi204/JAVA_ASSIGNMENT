
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Chinaza
 */
public class Main extends StudentPerformance{
     public static void main(String[] args)
    {
        Scanner myscan=new Scanner(System.in);
        StudentPerformance myobj=new StudentPerformance();
        System.out.println("Enter student name : ");
        myobj.name=myscan.next();
        System.out.println("Enter student ID : ");
        myobj.std_id=myscan.nextInt();
        System.out.println("Enter the number of subject : ");
        n=myscan.nextInt();
        int marks[] =new int[n];
        System.out.println("Enter the mark out of 100% : ");
        for(int i=0;i<n;i++)
        {
            marks[i]=myscan.nextInt();
            myobj.total=myobj.total+marks[i];
        }
        myobj.student_details();
        System.out.println("The total score : "+ myobj.total);
        myobj.percentage();
    }      
     
}
